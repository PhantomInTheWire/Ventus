rm -rf files/ftest files/womp_womp/ files/tello.txt files/sample2.pdf

