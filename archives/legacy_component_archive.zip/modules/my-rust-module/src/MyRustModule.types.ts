export type ChangeEventPayload = {
  value: string;
};

export type MyRustModuleViewProps = {
  name: string;
};
