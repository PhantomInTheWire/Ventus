import { Connect } from "@/components";

export default function App() {
  return <Connect />;
}
