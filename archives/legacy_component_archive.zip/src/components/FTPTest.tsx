import { StyleSheet, Text, View } from "react-native";

export default function () {
  return (
    <View style={styles.container}>
      <Text style={styles.text}></Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {},
  text: {},
});
