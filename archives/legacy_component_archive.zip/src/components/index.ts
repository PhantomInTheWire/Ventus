import Connect from "./Connect";
import Files from "./Files";
import Home from "./Home";
import TitleBar from "./TitleBar";
import Scan from "./Scan";
import Settings from "./Settings";

export { Connect, Files, Home, TitleBar, Scan, Settings };
