import CloseNetworkIcon from "./CloseNetwork";
import LogoutIcon from "./Logout";
import RemoveIcon from "./Remove";
import FolderIcon from "./Folder";
import IdIcon from "./Id";
import FilterIcon from "./Filter";
import LanIcon from "./Lan";
import SpeedIcon from "./Speed";

export { CloseNetworkIcon, LogoutIcon, RemoveIcon, FolderIcon, IdIcon, FilterIcon, LanIcon, SpeedIcon };
